library("testthat")
library("tinylabels")

test_check("tinylabels")
