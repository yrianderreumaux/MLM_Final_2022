#' Lightweight Variable Labels
#'
#' To learn more about tinylabels, take a look at the vignette: `browseVignettes(package = "tinylabels")`
#'
#' @section Maintainer:
#'    Marius Barth (marius.barth.uni.koeln at gmail.com).
#'
#' @docType package
#' @name tinylabels

NULL
