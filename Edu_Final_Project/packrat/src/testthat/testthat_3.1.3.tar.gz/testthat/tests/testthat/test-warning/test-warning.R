test_that("warning emitted", {
  warning("This is not a test", call. = FALSE)
})
