# can access nickname

    Code
      version$nickname
    Output
      [1] "Bird Hippie"

