library(testthat)
library(rmdfiltr)

test_check("rmdfiltr")
