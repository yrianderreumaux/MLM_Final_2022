library(testthat)
library(bookdown)

test_check("bookdown")
