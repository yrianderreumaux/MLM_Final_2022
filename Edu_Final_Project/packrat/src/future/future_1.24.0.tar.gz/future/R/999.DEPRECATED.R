## - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
## DEPRECATED & DEFUNCT
## - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#' @export
values <- function(...) {
  .Defunct(msg = "values() is defunct in future (>= 1.20.0). Use value() instead.", package = .packageName)
}
