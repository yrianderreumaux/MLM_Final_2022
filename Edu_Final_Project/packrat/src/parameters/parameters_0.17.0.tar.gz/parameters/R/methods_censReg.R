
#' @export
model_parameters.censReg <- model_parameters.default


#' @export
standard_error.censReg <- standard_error.default


#' @export
p_value.censReg <- p_value.default
