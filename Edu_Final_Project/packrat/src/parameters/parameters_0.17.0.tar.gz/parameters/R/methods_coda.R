#' @export
model_parameters.mcmc.list <- model_parameters.data.frame
