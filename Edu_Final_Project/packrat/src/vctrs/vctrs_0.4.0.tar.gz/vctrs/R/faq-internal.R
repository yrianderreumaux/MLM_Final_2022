#' Internal FAQ - `vec_ptype2()`, `NULL`, and unspecified vectors
#'
#' @includeRmd man/faq/internal/ptype2-identity.Rmd description
#'
#' @name internal-faq-ptype2-identity
NULL
