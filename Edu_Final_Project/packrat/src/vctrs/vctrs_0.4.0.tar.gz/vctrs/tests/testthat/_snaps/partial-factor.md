# has ok print method

    Code
      partial
    Output
      partial_factor<
        bf275 {partial}
      >

---

    Code
      both
    Output
      partial_factor<
        bf275 {partial}
        fd1ad
      >

---

    Code
      empty
    Output
      partial_factor<
      
      >

---

    Code
      learned
    Output
      partial_factor<
        fd1ad
      >

