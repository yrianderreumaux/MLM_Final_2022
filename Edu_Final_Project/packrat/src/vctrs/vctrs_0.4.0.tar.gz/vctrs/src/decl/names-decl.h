static
r_obj* check_unique_names(r_obj* names,
                          const struct name_repair_opts* opts);
