static r_obj* list_drop_empty(r_obj* x);
