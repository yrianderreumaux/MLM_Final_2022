static inline
void int64_unpack(int64_t x, r_ssize i, double* v_left, double* v_right);

static inline
int64_t int64_pack(double left, double right);
