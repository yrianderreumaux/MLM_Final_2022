#ifndef RLANG_ARG_H
#define RLANG_ARG_H


extern int (*r_arg_match)(r_obj* arg, r_obj* values, r_obj* error_arg, r_obj* error_call);


#endif
