#ifndef VCTRS_COMPLETE_H
#define VCTRS_COMPLETE_H

#include "vctrs-core.h"

r_obj* vec_detect_complete(r_obj* x);

#endif
