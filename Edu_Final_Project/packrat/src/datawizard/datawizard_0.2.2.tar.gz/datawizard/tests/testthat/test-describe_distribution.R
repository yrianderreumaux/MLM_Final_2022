if (require("testthat")) {
  test_that("describe_distribution", {
    x <- describe_distribution(rnorm(100))
    expect_equal(c(nrow(x), ncol(x)), c(1, 9))
  })
}
