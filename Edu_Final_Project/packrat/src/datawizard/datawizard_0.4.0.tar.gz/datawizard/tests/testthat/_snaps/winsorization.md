# with missing values

    Code
      suppressWarnings(head(winsorize(na.omit(ggplot2::msleep$brainwt))))
    Output
      [1] 0.0155 0.0024 0.1750 0.0700 0.0982 0.1150

